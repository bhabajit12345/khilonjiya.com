package com.marketplace_pro.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
